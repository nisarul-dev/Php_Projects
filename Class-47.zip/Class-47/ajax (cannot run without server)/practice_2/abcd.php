<?php
echo "My username is ", $_POST['username'] . " and my Password is " . $_POST['password'];