<?php
echo "My username is " . $_POST['user_name'] . " and my Password is " . $_POST['pass_word'];